<header class="nxl-header">
    <div class="header-wrapper">
        <div class="header-left d-flex align-items-center gap-4">
            <a href="javascript:void(0);" class="nxl-head-mobile-toggler" id="mobile-collapse">
                <div class="hamburger hamburger--arrowturn">
                    <div class="hamburger-box">
                        <div class="hamburger-inner"></div>
                    </div>
                </div>
            </a>

            <div class="nxl-navigation-toggle">
                <a href="javascript:void(0);" id="menu-mini-button">
                    <i class="feather-align-left"></i>
                </a>
                <a href="javascript:void(0);" id="menu-expend-button" style="display: none">
                    <i class="feather-arrow-right"></i>
                </a>
            </div>

            <div class="nxl-lavel-mega-menu-toggle d-flex d-lg-none">
                <a href="javascript:void(0);" id="nxl-lavel-mega-menu-open">
                    <i class="feather-align-left"></i>
                </a>
            </div>

            <div class="nxl-drp-link nxl-lavel-mega-menu">
                <div class="nxl-lavel-mega-menu-toggle d-flex d-lg-none">
                    <a href="javascript:void(0)" id="nxl-lavel-mega-menu-hide">
                        <i class="feather-arrow-left me-2"></i>
                        <span>Back</span>
                    </a>
                </div>

                @php
                    $levelMenus = [
                        ['title' => 'Applications', 'icon' => 'feather-send', 'links' => ['Chat', 'Email', 'Tasks', 'Notes', 'Storage', 'Calendar']],
                        ['title' => 'Reports', 'icon' => 'feather-cast', 'links' => ['Sales Report', 'Leads Report', 'Project Report', 'Timesheets Report']],
                        ['title' => 'Proposal', 'icon' => 'feather-at-sign', 'links' => ['Proposal', 'Proposal View', 'Proposal Edit', 'Proposal Create']],
                        ['title' => 'Payment', 'icon' => 'feather-dollar-sign', 'links' => ['Payment', 'Invoice View', 'Invoice Create']],
                        ['title' => 'Customers', 'icon' => 'feather-users', 'links' => ['Customers', 'Customers View', 'Customers Create']],
                        ['title' => 'Leads', 'icon' => 'feather-alert-circle', 'links' => ['Leads', 'Leads View', 'Leads Create']],
                        ['title' => 'Projects', 'icon' => 'feather-briefcase', 'links' => ['Projects', 'Projects View', 'Projects Create']],
                        ['title' => 'Widgets', 'icon' => 'feather-layout', 'links' => ['Lists', 'Tables', 'Charts', 'Statistics']],
                        ['title' => 'Authentication', 'icon' => 'feather-power', 'links' => ['Login', 'Register', 'Error-404', 'Reset Pass', 'Verify OTP', 'Maintenance']],
                    ];

                    $megaTabs = [
                        ['target' => 'v-pills-general', 'size' => 'sm', 'icon' => 'feather-airplay', 'title' => 'General'],
                        ['target' => 'v-pills-applications', 'size' => 'md', 'icon' => 'feather-send', 'title' => 'Applications'],
                        ['target' => 'v-pills-integrations', 'size' => 'lg', 'icon' => 'feather-link-2', 'title' => 'Integrations'],
                        ['target' => 'v-pills-components', 'size' => 'xl', 'icon' => 'feather-layers', 'title' => 'Components'],
                        ['target' => 'v-pills-authentication', 'size' => 'xxl', 'icon' => 'feather-cpu', 'title' => 'Authentication'],
                        ['target' => 'v-pills-miscellaneous', 'size' => 'full', 'icon' => 'feather-bluetooth', 'title' => 'Miscellaneous'],
                    ];
                @endphp

                <div class="nxl-lavel-mega-menu-wrapper d-flex gap-3">
                    <div class="dropdown nxl-h-item nxl-lavel-menu">
                        <a href="javascript:void(0);" class="avatar-text avatar-md bg-primary text-white" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                            <i class="feather-plus"></i>
                        </a>
                        <div class="dropdown-menu nxl-h-dropdown">
                            @foreach ($levelMenus as $index => $menu)
                                @if ($index === 1 || $index === 8)
                                    <div class="dropdown-divider"></div>
                                @endif
                                <div class="dropdown nxl-level-menu">
                                    <a href="javascript:void(0);" class="dropdown-item">
                                        <span class="hstack">
                                            <i class="{{ $menu['icon'] }}"></i>
                                            <span>{{ $menu['title'] }}</span>
                                        </span>
                                        <i class="feather-chevron-right ms-auto me-0"></i>
                                    </a>
                                    <div class="dropdown-menu nxl-h-dropdown">
                                        @foreach ($menu['links'] as $link)
                                            <a href="javascript:void(0);" class="dropdown-item">
                                                <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                <span>{{ $link }}</span>
                                            </a>
                                        @endforeach
                                    </div>
                                </div>
                            @endforeach
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-plus"></i>
                                <span>Add New Items</span>
                            </a>
                        </div>
                    </div>

                    <div class="dropdown nxl-h-item nxl-mega-menu">
                        <a href="javascript:void(0);" class="btn btn-light-brand" data-bs-toggle="dropdown" data-bs-auto-close="outside"> Mega Menu </a>
                        <div class="dropdown-menu nxl-h-dropdown" id="mega-menu-dropdown">
                            <div class="d-lg-flex align-items-start">
                                <div class="nav flex-column nxl-mega-menu-tabs" role="tablist" aria-orientation="vertical">
                                    @foreach ($megaTabs as $index => $tab)
                                        <button class="nav-link {{ $index === 0 ? 'active' : '' }} nxl-mega-menu-{{ $tab['size'] }}" data-bs-toggle="pill" data-bs-target="#{{ $tab['target'] }}" type="button" role="tab">
                                            <span class="menu-icon">
                                                <i class="{{ $tab['icon'] }}"></i>
                                            </span>
                                            <span class="menu-title">{{ $tab['title'] }}</span>
                                            <span class="menu-arrow">
                                                <i class="feather-chevron-right"></i>
                                            </span>
                                        </button>
                                    @endforeach
                                </div>

                                <div class="tab-content nxl-mega-menu-tabs-content">
                                    <div class="tab-pane fade show active" id="v-pills-general" role="tabpanel">
                                        <div class="mb-4 rounded-3 border">
                                            <img src="{{ asset('assets/images/banner/mockup.png') }}" alt="" class="img-fluid rounded-3">
                                        </div>
                                        <h6 class="fw-bolder">Duralux - Admin Dashboard UiKit</h6>
                                        <p class="fs-12 fw-normal text-muted text-truncate-3-line">Get started with Duralux dashboard components, navigation, apps, authentication pages, and reusable widgets.</p>
                                        <a href="javascript:void(0);" class="fs-13 fw-bold text-primary">Get Started &rarr;</a>
                                    </div>

                                    <div class="tab-pane fade" id="v-pills-applications" role="tabpanel">
                                        <div class="row g-4">
                                            <div class="col-lg-6">
                                                <h6 class="dropdown-item-title">Applications</h6>
                                                @foreach (['Chat', 'Email', 'Tasks', 'Notes', 'Storage', 'Calendar'] as $appLink)
                                                    <a href="javascript:void(0);" class="dropdown-item">
                                                        <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                        <span>{{ $appLink }}</span>
                                                    </a>
                                                @endforeach
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="nxl-mega-menu-image">
                                                    <img src="{{ asset('assets/images/general/full-avatar.png') }}" alt="" class="img-fluid full-user-avtar">
                                                </div>
                                            </div>
                                        </div>
                                        <hr class="border-top-dashed">
                                        <div class="d-lg-flex align-items-center justify-content-between">
                                            <div>
                                                <h6 class="menu-item-heading text-truncate-1-line">Need more application?</h6>
                                                <p class="fs-12 text-muted mb-0 text-truncate-3-line">We are ready to build custom applications.</p>
                                            </div>
                                            <a href="javascript:void(0);" class="fs-13 fw-bold text-primary">Contact Us &rarr;</a>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="v-pills-integrations" role="tabpanel">
                                        <div class="row g-lg-4 nxl-mega-menu-integrations">
                                            <div class="col-lg-12 d-lg-flex align-items-center justify-content-between mb-4 mb-lg-0">
                                                <div>
                                                    <h6 class="fw-bolder text-dark">Integrations</h6>
                                                    <p class="fs-12 text-muted mb-0">Connect amazing apps on your bucket.</p>
                                                </div>
                                                <a href="javascript:void(0);" class="fs-13 text-primary">Add New &rarr;</a>
                                            </div>
                                            @foreach (array_chunk([
                                                ['app-store.png', 'App Store'], ['spotify.png', 'Spotify'], ['figma.png', 'Figma'], ['shopify.png', 'Shopify'], ['paypal.png', 'Paypal'],
                                                ['gmail.png', 'Gmail'], ['dropbox.png', 'Dropbox'], ['google-drive.png', 'Google Drive'], ['github.png', 'Github'], ['gitlab.png', 'Gitlab'],
                                                ['facebook.png', 'Facebook'], ['pinterest.png', 'Pinterest'], ['instagram.png', 'Instagram'], ['twitter.png', 'Twitter'], ['youtube.png', 'Youtube'],
                                            ], 5) as $integrationGroup)
                                                <div class="col-lg-4">
                                                    @foreach ($integrationGroup as [$image, $title])
                                                        <a href="javascript:void(0);" class="dropdown-item">
                                                            <div class="menu-item-icon">
                                                                <img src="{{ asset('assets/images/brand/' . $image) }}" alt="" class="img-fluid">
                                                            </div>
                                                            <div class="menu-item-title">{{ $title }}</div>
                                                            <div class="menu-item-arrow">
                                                                <i class="feather-arrow-right"></i>
                                                            </div>
                                                        </a>
                                                    @endforeach
                                                </div>
                                            @endforeach
                                        </div>
                                        <hr class="border-top-dashed">
                                        <p class="fs-13 text-muted mb-0">Need help? Contact our <a href="javascript:void(0);" class="fst-italic">support center</a></p>
                                    </div>

                                    <div class="tab-pane fade" id="v-pills-components" role="tabpanel">
                                        <div class="row g-4 align-items-center">
                                            <div class="col-xl-8">
                                                <div class="row g-4">
                                                    @foreach ([
                                                        'Navigation' => ['CRM', 'Analytics', 'Sales', 'Leads', 'Projects', 'Timesheets'],
                                                        'Pages' => ['Leads', 'Payments', 'Projects', 'Proposals', 'Customers', 'Documentations'],
                                                        'Authentication' => ['Login', 'Register', 'Error-404', 'Reset Pass', 'Verify OTP', 'Maintenance'],
                                                    ] as $title => $links)
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">{{ $title }}</h6>
                                                            @foreach ($links as $link)
                                                                <a href="javascript:void(0);" class="dropdown-item">{{ $link }}</a>
                                                            @endforeach
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="nxl-mega-menu-image">
                                                    <img src="{{ asset('assets/images/banner/1.jpg') }}" alt="" class="img-fluid">
                                                </div>
                                                <div class="mt-4">
                                                    <a href="javascript:void(0);" class="fs-13 fw-bold">View all resources on Duralux &rarr;</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="v-pills-authentication" role="tabpanel">
                                        <div class="row g-4 align-items-center nxl-mega-menu-authentication">
                                            <div class="col-xl-8">
                                                <div class="row g-4">
                                                    @foreach (['Cover', 'Minimal', 'Creative'] as $authType)
                                                        <div class="col-lg-4">
                                                            <h6 class="dropdown-item-title">{{ $authType }}</h6>
                                                            @foreach (['Login', 'Register', 'Error-404', 'Reset Pass', 'Verify OTP', 'Maintenance'] as $authLink)
                                                                <a href="javascript:void(0);" class="dropdown-item">
                                                                    <i class="wd-5 ht-5 bg-gray-500 rounded-circle me-3"></i>
                                                                    <span>{{ $authLink }}</span>
                                                                </a>
                                                            @endforeach
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div id="carouselResourcesCaptions" class="carousel slide" data-bs-ride="carousel">
                                                    <div class="carousel-inner rounded-3">
                                                        @foreach ([6, 5, 4] as $index => $banner)
                                                            <div class="carousel-item {{ $index === 0 ? 'active' : '' }}">
                                                                <div class="nxl-mega-menu-image">
                                                                    <img src="{{ asset('assets/images/banner/' . $banner . '.jpg') }}" alt="" class="img-fluid d-block w-100">
                                                                </div>
                                                                <div class="carousel-caption">
                                                                    <h5 class="carousel-caption-title text-truncate-1-line">Duralux Dashboard</h5>
                                                                    <p class="carousel-caption-desc">Reusable dashboard screens and auth pages.</p>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade nxl-mega-menu-miscellaneous" id="v-pills-miscellaneous" role="tabpanel">
                                        <ul class="nav nav-tabs flex-column flex-lg-row nxl-mega-menu-miscellaneous-tabs" role="tablist">
                                            @foreach (['Projects' => 'feather-cast', 'Services' => 'feather-check-square', 'Features' => 'feather-airplay', 'Blogs' => 'feather-bold'] as $tabTitle => $tabIcon)
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link {{ $loop->first ? 'active' : '' }}" data-bs-toggle="tab" data-bs-target="#mega-{{ strtolower($tabTitle) }}" type="button" role="tab">
                                                        <span class="menu-icon">
                                                            <i class="{{ $tabIcon }}"></i>
                                                        </span>
                                                        <span class="menu-title">{{ $tabTitle }}</span>
                                                    </button>
                                                </li>
                                            @endforeach
                                        </ul>
                                        <div class="tab-content nxl-mega-menu-miscellaneous-content">
                                            @foreach (['Projects', 'Services', 'Features', 'Blogs'] as $miscTab)
                                                <div class="tab-pane fade {{ $loop->first ? 'active show' : '' }}" id="mega-{{ strtolower($miscTab) }}" role="tabpanel">
                                                    <div class="row g-4">
                                                        @foreach ([1, 2, 3, 4] as $banner)
                                                            <div class="col-xl-6">
                                                                <div class="d-lg-flex align-items-center gap-3">
                                                                    <div class="wd-150 rounded-3">
                                                                        <img src="{{ asset('assets/images/banner/' . $banner . '.jpg') }}" alt="" class="img-fluid rounded-3">
                                                                    </div>
                                                                    <div class="mt-3 mt-lg-0 ms-lg-3 item-text">
                                                                        <a href="javascript:void(0);">
                                                                            <h6 class="menu-item-heading text-truncate-1-line">{{ $miscTab }} Resource</h6>
                                                                        </a>
                                                                        <p class="fs-12 fw-normal text-muted mb-0 text-truncate-2-line">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                                                        <div class="hstack gap-2 mt-3">
                                                                            <div class="avatar-image avatar-sm">
                                                                                <img src="{{ asset('assets/images/avatar/' . $banner . '.png') }}" alt="" class="img-fluid">
                                                                            </div>
                                                                            <a href="javascript:void(0);" class="fs-12">Duralux Team</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header-right ms-auto">
            <div class="d-flex align-items-center">
                <div class="dropdown nxl-h-item nxl-header-search">
                    <a href="javascript:void(0);" class="nxl-head-link me-0" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                        <i class="feather-search"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-search-dropdown">
                        <div class="input-group search-form">
                            <span class="input-group-text">
                                <i class="feather-search fs-6 text-muted"></i>
                            </span>
                            <input type="text" class="form-control search-input-field" placeholder="Search customers, invoices, stock, payroll">
                            <span class="input-group-text">
                                <button type="button" class="btn-close"></button>
                            </span>
                        </div>
                        <div class="dropdown-divider mt-0"></div>
                        <div class="search-items-wrapper">
                            <div class="searching-for px-4 py-2">
                                <p class="fs-11 fw-medium text-muted">I'm searching for...</p>
                                <div class="d-flex flex-wrap gap-1">
                                    @foreach (['Customers', 'Invoices', 'Inventory', 'Suppliers', 'Payroll', 'Projects', 'Approvals', 'Reports'] as $searchScope)
                                        <a href="javascript:void(0);" class="flex-fill border rounded py-1 px-2 text-center fs-11 fw-semibold">{{ $searchScope }}</a>
                                    @endforeach
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <div class="recent-result px-4 py-2">
                                <h4 class="fs-13 fw-normal text-gray-600 mb-3">Recent <span class="badge small bg-gray-200 rounded ms-1 text-dark">3</span></h4>
                                @foreach ([
                                    ['icon' => 'feather-file-text', 'title' => 'Monthly tax summary', 'path' => 'Finance / reports'],
                                    ['icon' => 'feather-package', 'title' => 'Low stock approvals', 'path' => 'Inventory / approvals'],
                                    ['icon' => 'feather-users', 'title' => 'Enterprise customer list', 'path' => 'CRM / customers'],
                                ] as $recent)
                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div class="d-flex align-items-center gap-3">
                                            <div class="avatar-text rounded">
                                                <i class="{{ $recent['icon'] }}"></i>
                                            </div>
                                            <div>
                                                <a href="javascript:void(0);" class="font-body fw-bold d-block mb-1">{{ $recent['title'] }}</a>
                                                <p class="fs-11 text-muted mb-0">{{ $recent['path'] }}</p>
                                            </div>
                                        </div>
                                        <a href="javascript:void(0);" class="avatar-text avatar-md">
                                            <i class="feather-chevron-right"></i>
                                        </a>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

                <div class="dropdown nxl-h-item nxl-header-language d-none d-sm-flex">
                    <a href="javascript:void(0);" class="nxl-head-link me-0 nxl-language-link" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                        <img src="{{ asset('assets/vendors/img/flags/4x3/us.svg') }}" alt="English" class="img-fluid wd-20">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-language-dropdown">
                        <div class="dropdown-divider mt-0"></div>
                        <div class="language-items-wrapper">
                            <div class="select-language px-4 py-2 hstack justify-content-between gap-4">
                                <div class="lh-lg">
                                    <h6 class="mb-0">Select Language</h6>
                                    <p class="fs-11 text-muted mb-0">12 languages available!</p>
                                </div>
                                <a href="javascript:void(0);" class="avatar-text avatar-md" data-bs-toggle="tooltip" title="Add Language">
                                    <i class="feather-plus"></i>
                                </a>
                            </div>
                            <div class="dropdown-divider"></div>
                            <div class="row px-4 pt-3">
                                @foreach ([
                                    ['code' => 'sa', 'name' => 'Arabic'],
                                    ['code' => 'bd', 'name' => 'Bengali'],
                                    ['code' => 'cn', 'name' => 'Chinese'],
                                    ['code' => 'nl', 'name' => 'Dutch'],
                                    ['code' => 'us', 'name' => 'English', 'active' => true],
                                    ['code' => 'fr', 'name' => 'French'],
                                    ['code' => 'de', 'name' => 'German'],
                                    ['code' => 'in', 'name' => 'Hindi'],
                                    ['code' => 'ru', 'name' => 'Russian'],
                                    ['code' => 'es', 'name' => 'Spanish'],
                                    ['code' => 'tr', 'name' => 'Turkish'],
                                    ['code' => 'pk', 'name' => 'Urdu'],
                                ] as $language)
                                    <div class="col-sm-4 col-6 language_select {{ !empty($language['active']) ? 'active' : '' }}">
                                        <a href="javascript:void(0);" class="d-flex align-items-center gap-2" data-language="{{ $language['name'] }}" data-flag="{{ asset('assets/vendors/img/flags/4x3/' . $language['code'] . '.svg') }}">
                                            <div class="avatar-image avatar-sm">
                                                <img src="{{ asset('assets/vendors/img/flags/1x1/' . $language['code'] . '.svg') }}" alt="{{ $language['name'] }}" class="img-fluid">
                                            </div>
                                            <span>{{ $language['name'] }}</span>
                                        </a>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

                <div class="nxl-h-item d-none d-sm-flex">
                    <div class="full-screen-switcher">
                        <a href="javascript:void(0);" class="nxl-head-link me-0" onclick="$('body').fullScreenHelper('toggle');">
                            <i class="feather-maximize maximize"></i>
                            <i class="feather-minimize minimize"></i>
                        </a>
                    </div>
                </div>

                <div class="nxl-h-item dark-light-theme">
                    <a href="javascript:void(0);" class="nxl-head-link me-0 dark-button">
                        <i class="feather-moon"></i>
                    </a>
                    <a href="javascript:void(0);" class="nxl-head-link me-0 light-button" style="display: none">
                        <i class="feather-sun"></i>
                    </a>
                </div>

                <div class="dropdown nxl-h-item">
                    <a href="javascript:void(0);" class="nxl-head-link me-0" data-bs-toggle="dropdown" role="button" data-bs-auto-close="outside">
                        <i class="feather-clock"></i>
                        <span class="badge bg-success nxl-h-badge">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-timesheets-menu">
                        <div class="d-flex justify-content-between align-items-center timesheets-head">
                            <h6 class="fw-bold text-dark mb-0">Approvals</h6>
                            <a href="javascript:void(0);" class="fs-11 text-success text-end ms-auto">
                                <i class="feather-clock"></i>
                                <span>Due Today</span>
                            </a>
                        </div>
                        <div class="d-flex justify-content-between align-items-center flex-column timesheets-body">
                            <i class="feather-check-square fs-1 mb-4"></i>
                            <p class="text-muted">No urgent approvals waiting.</p>
                            <a href="javascript:void(0);" class="btn btn-sm btn-primary">Open Center</a>
                        </div>
                        <div class="text-center timesheets-footer">
                            <a href="javascript:void(0);" class="fs-13 fw-semibold text-dark">All Approvals</a>
                        </div>
                    </div>
                </div>

                <div class="dropdown nxl-h-item">
                    <a class="nxl-head-link me-3" data-bs-toggle="dropdown" href="#" role="button" data-bs-auto-close="outside">
                        <i class="feather-bell"></i>
                        <span class="badge bg-danger nxl-h-badge">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-notifications-menu">
                        <div class="d-flex justify-content-between align-items-center notifications-head">
                            <h6 class="fw-bold text-dark mb-0">Notifications</h6>
                            <a href="javascript:void(0);" class="fs-11 text-success text-end ms-auto">
                                <i class="feather-check"></i>
                                <span>Mark as Read</span>
                            </a>
                        </div>
                        @foreach ([
                            ['avatar' => '2.png', 'name' => 'Sales Team', 'body' => 'New enterprise quotation needs margin approval.', 'time' => '2 minutes ago'],
                            ['avatar' => '3.png', 'name' => 'Inventory', 'body' => '18 items crossed reorder level.', 'time' => '36 minutes ago'],
                            ['avatar' => '4.png', 'name' => 'Payroll', 'body' => 'June payroll draft is ready for review.', 'time' => '53 minutes ago'],
                        ] as $notification)
                            <div class="notifications-item">
                                <img src="{{ asset('assets/images/avatar/' . $notification['avatar']) }}" alt="" class="rounded me-3 border">
                                <div class="notifications-desc">
                                    <a href="javascript:void(0);" class="font-body text-truncate-2-line">
                                        <span class="fw-semibold text-dark">{{ $notification['name'] }}</span>
                                        {{ $notification['body'] }}
                                    </a>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="notifications-date text-muted border-bottom border-bottom-dashed">{{ $notification['time'] }}</div>
                                        <a href="javascript:void(0);" class="text-danger">
                                            <i class="feather-x fs-12"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        <div class="text-center notifications-footer">
                            <a href="javascript:void(0);" class="fs-13 fw-semibold text-dark">All Notifications</a>
                        </div>
                    </div>
                </div>

                <div class="dropdown nxl-h-item">
                    <a href="javascript:void(0);" data-bs-toggle="dropdown" role="button" data-bs-auto-close="outside">
                        <img src="{{ asset('assets/images/avatar/1.png') }}" alt="user-image" class="img-fluid user-avtar me-0">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end nxl-h-dropdown nxl-user-dropdown">
                        <div class="dropdown-header">
                            <div class="d-flex align-items-center">
                                <img src="{{ asset('assets/images/avatar/1.png') }}" alt="user-image" class="img-fluid user-avtar">
                                <div>
                                    <h6 class="text-dark mb-0">ERP Admin <span class="badge bg-soft-success text-success ms-1">PRO</span></h6>
                                    <span class="fs-12 fw-medium text-muted">admin@saas-erp.local</span>
                                </div>
                            </div>
                        </div>
                        <a href="javascript:void(0);" class="dropdown-item">
                            <i class="feather-user"></i>
                            <span>Profile Details</span>
                        </a>
                        <a href="javascript:void(0);" class="dropdown-item">
                            <i class="feather-activity"></i>
                            <span>Activity Feed</span>
                        </a>
                        <a href="javascript:void(0);" class="dropdown-item">
                            <i class="feather-settings"></i>
                            <span>Account Settings</span>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="javascript:void(0);" class="dropdown-item">
                            <i class="feather-log-out"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
