@php
    $modules = [
        'Workspace' => [
            ['label' => 'Executive Dashboard', 'icon' => 'feather-home', 'route' => 'dashboard'],
            ['label' => 'Companies & Tenants', 'icon' => 'feather-grid', 'url' => '#'],
            ['label' => 'Approvals Center', 'icon' => 'feather-check-square', 'url' => '#'],
        ],
        'Revenue' => [
            ['label' => 'CRM', 'icon' => 'feather-users', 'url' => '#', 'children' => ['Leads', 'Customers', 'Contacts', 'Activities']],
            ['label' => 'Sales', 'icon' => 'feather-shopping-cart', 'url' => '#', 'children' => ['Quotations', 'Orders', 'Invoices', 'Receipts']],
            ['label' => 'Projects', 'icon' => 'feather-briefcase', 'url' => '#', 'children' => ['Projects', 'Milestones', 'Tasks', 'Timesheets']],
        ],
        'Operations' => [
            ['label' => 'Inventory', 'icon' => 'feather-box', 'url' => '#', 'children' => ['Items', 'Warehouses', 'Stock Moves', 'Adjustments']],
            ['label' => 'Purchase', 'icon' => 'feather-truck', 'url' => '#', 'children' => ['Suppliers', 'Requests', 'Purchase Orders', 'Bills']],
            ['label' => 'Production', 'icon' => 'feather-cpu', 'url' => '#', 'children' => ['BOM', 'Work Orders', 'Planning', 'Quality']],
        ],
        'People & Finance' => [
            ['label' => 'HRMS', 'icon' => 'feather-user-check', 'url' => '#', 'children' => ['Employees', 'Attendance', 'Leave', 'Payroll']],
            ['label' => 'Accounting', 'icon' => 'feather-credit-card', 'url' => '#', 'children' => ['Chart of Accounts', 'Journals', 'Ledgers', 'Reports']],
            ['label' => 'Administration', 'icon' => 'feather-settings', 'url' => '#', 'children' => ['Roles', 'Workflows', 'Audit Logs', 'Settings']],
        ],
    ];
@endphp

<nav class="nxl-navigation">
    <div class="navbar-wrapper">
        <div class="m-header">
            <a href="{{ route('dashboard') }}" class="b-brand">
                <img src="{{ asset('assets/images/logo-full.png') }}" alt="SaaS ERP" class="logo logo-lg logo-full">
                <img src="{{ asset('assets/images/logo-abbr.png') }}" alt="SaaS ERP" class="logo logo-sm logo-abbr">
            </a>
        </div>
        <div class="navbar-content">
            <ul class="nxl-navbar">
                @foreach ($modules as $caption => $items)
                    <li class="nxl-item nxl-caption">
                        <label>{{ $caption }}</label>
                    </li>
                    @foreach ($items as $item)
                        @php
                            $href = isset($item['route']) ? route($item['route']) : $item['url'];
                            $hasChildren = isset($item['children']);
                        @endphp
                        <li class="nxl-item {{ $hasChildren ? 'nxl-hasmenu' : '' }} {{ isset($item['route']) && request()->routeIs($item['route']) ? 'active' : '' }}">
                            <a href="{{ $hasChildren ? 'javascript:void(0);' : $href }}" class="nxl-link">
                                <span class="nxl-micon"><i class="{{ $item['icon'] }}"></i></span>
                                <span class="nxl-mtext">{{ $item['label'] }}</span>
                                @if ($hasChildren)
                                    <span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                                @endif
                            </a>
                            @if ($hasChildren)
                                <ul class="nxl-submenu">
                                    @foreach ($item['children'] as $child)
                                        <li class="nxl-item">
                                            <a class="nxl-link" href="#">{{ $child }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                    @endforeach
                @endforeach
            </ul>
            <div class="card text-center">
                <div class="card-body">
                    <i class="feather-activity fs-4 text-dark"></i>
                    <h6 class="mt-4 text-dark fw-bolder">ERP Control Center</h6>
                    <p class="fs-11 my-3 text-dark">Track tenants, approvals, finance, stock, and payroll from one Duralux workspace.</p>
                    <a href="{{ route('dashboard') }}" class="btn btn-primary text-dark w-100">Open Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</nav>
